/**
 * 
 */
/**
 * 
 */
module JavaCaseStudy {
}
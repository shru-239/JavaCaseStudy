/**
 * 
 */
/**
 * 
 */
module JavaCaseStudy2 {
}